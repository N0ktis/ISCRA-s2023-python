SECRET_KEY = 'dev'
