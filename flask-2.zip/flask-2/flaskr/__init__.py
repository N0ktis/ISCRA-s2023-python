from flask import Flask, render_template
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config.from_mapping(SQLALCHEMY_DATABASE_URI='sqlite:///flaskr.sqlite')

app.config.from_pyfile('config.py')

db = SQLAlchemy(app)

from . import auth
app.register_blueprint(auth.bp)

from . import blog
app.register_blueprint(blog.bp)

from . import models
# Command Line Interface
app.cli.add_command(models.init_db_command)

# templates
# static
