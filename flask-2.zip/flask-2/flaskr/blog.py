from flask import Blueprint, render_template, request, redirect, url_for, flash, session, g, abort
from werkzeug.security import generate_password_hash, check_password_hash

from flaskr import db
from flaskr.auth import login_required
from flaskr.models import User, Post

bp = Blueprint('blog', __name__)

@bp.route('/')
def index():
    posts = Post.query.all()
    return render_template('blog/index.html', posts=posts)

@bp.route('/create', methods=['GET', 'POST'])
@login_required
def create():
    if request.method == 'POST':
        title = request.form['title']
        body = request.form['body']
        error = None

        if not title:
            error = 'Title is empty'
        elif not body:
            error = 'Body is empty'

        if error is not None:
            flash(error)
        else:
            post = Post(title=title, body=body, author_id=g.user.id)
            db.session.add(post)
            db.session.commit()

            return redirect(url_for('blog.index'))

    return render_template('blog/create.html')

def get_post(id):
    post: Post = Post.query.get(id)

    if post is None:
        abort(404, f'Post with id {id} does not exists')

    if post.author.id != g.user.id:
        abort(403)

    return post

@bp.route('/<int:id>/edit', methods=['GET', 'POST'])
@login_required
def edit(id):
    post = get_post(id)

    if request.method == 'POST':
        post.title = request.form['title']
        post.body = request.form['body']
        db.session.commit()
        return redirect(url_for('blog.index'))


    return render_template('blog/edit.html', post=post)

@bp.route('/<int:id>/delete', methods=['GET', 'POST'])
@login_required
def delete(id):
    post = get_post(id)

    db.session.delete(post)
    db.session.commit()

    return redirect(url_for('blog.index'))

