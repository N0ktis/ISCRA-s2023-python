from flask_sqlalchemy.model import Model
from sqlalchemy import text

from flaskr import db, app
import click

db.Model: Model

# declarative_base
class User(db.Model):
    __tablename__ = 'user'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.Text, unique=True, nullable=False)
    password = db.Column(db.Text, nullable=False)
    # post

    # representation
    def __repr__(self):
        return f'<User {self.username}>'

class Post(db.Model):
    __tablename__ = 'post'
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.Text, nullable=False)
    body = db.Column(db.Text, nullable=False)
    created = db.Column(db.TIMESTAMP, nullable=False, server_default=text('CURRENT_TIMESTAMP'))
    author_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    author = db.relationship('User')

def init_db():
    with app.app_context():
        db.drop_all()
        db.create_all()

@click.command('init-db')
def init_db_command():
    init_db()
    click.echo('Database initialized successfully')

