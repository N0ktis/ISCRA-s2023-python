from flaskr import app, db

# app.run()
from flaskr.models import User

with app.app_context():
    data = User.query.all()
    print([x.password for x in data])
